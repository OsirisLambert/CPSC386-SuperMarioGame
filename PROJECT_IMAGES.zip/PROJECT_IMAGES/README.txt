The contents of this file should be placed in the same file as the .py files

This file(PROJECT_IMAGES, whould not be included. just it's contents
this file was jsut made for ease of upload